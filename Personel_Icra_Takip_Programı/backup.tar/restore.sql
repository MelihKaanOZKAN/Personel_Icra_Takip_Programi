--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tb_personel DROP CONSTRAINT fk_tb_personel_tb_kurumlar;
ALTER TABLE ONLY public.tb_muzekkereler DROP CONSTRAINT fk_tb_muzekkereler_tb_icralar;
ALTER TABLE ONLY public.tb_kurumlar DROP CONSTRAINT fk_tb_kurumlar_tb_gmudurluk;
ALTER TABLE ONLY public.tb_kesintiler DROP CONSTRAINT fk_tb_kesintiler_tb_personel;
ALTER TABLE ONLY public.tb_kesintiler DROP CONSTRAINT fk_tb_kesintiler_tb_icralar;
ALTER TABLE ONLY public.tb_kesintiler DROP CONSTRAINT fk_tb_kesintiler;
ALTER TABLE ONLY public.tb_icralar DROP CONSTRAINT fk_tb_icralar_tb_icradairesi;
ALTER TABLE ONLY public.tb_ekler DROP CONSTRAINT fk_tb_ekler_tb_cevaplar;
ALTER TABLE ONLY public.tb_cevaplar DROP CONSTRAINT fk_tb_cevaplar_tb_icralar;
ALTER TABLE ONLY public.tb_borclular DROP CONSTRAINT fk_tb_borclular_tb_personel;
ALTER TABLE ONLY public.tb_borclular DROP CONSTRAINT fk_tb_borclular_tb_icralar;
ALTER TABLE ONLY public.tb_icralar DROP CONSTRAINT fk_icralar_turler;
ALTER TABLE ONLY public.tb_cevaplar_ekler DROP CONSTRAINT fk_ekler_cevaplar;
ALTER TABLE ONLY public.tb_icra_alacak DROP CONSTRAINT "fk_alacak_icra-icra";
ALTER TABLE ONLY public.tb_icra_alacak DROP CONSTRAINT "fk_alacak_icra-alacak";
DROP INDEX public.idx_tb_personel_ckurum;
DROP INDEX public.idx_tb_muzekkereler_icra;
DROP INDEX public.idx_tb_kurumlar_genelmudurluk;
DROP INDEX public.idx_tb_kesintiler_tur;
DROP INDEX public.idx_tb_kesintiler_kisi;
DROP INDEX public.idx_tb_kesintiler_icra;
DROP INDEX public.idx_tb_icralar_icradairesi;
DROP INDEX public.idx_tb_ekler_evrak_kayit_numarasi;
DROP INDEX public.idx_tb_cevaplar_icra;
DROP INDEX public.idx_tb_borclular_icra;
DROP INDEX public.fki_fk_icralar_turler;
ALTER TABLE ONLY public.tb_personel DROP CONSTRAINT unq_tcno;
ALTER TABLE ONLY public.tb_cevaplar_ekler DROP CONSTRAINT tb_cevaplar_ekler_pkey;
ALTER TABLE ONLY public.tb_icra_turleri DROP CONSTRAINT pkey_icra_turleri;
ALTER TABLE ONLY public.tb_personel DROP CONSTRAINT "pk_tb_personel_kişi_no";
ALTER TABLE ONLY public.tb_muzekkereler DROP CONSTRAINT pk_tb_muzekkereler_kayitno;
ALTER TABLE ONLY public.tb_kurumlar DROP CONSTRAINT pk_tb_kurumlar_kk5;
ALTER TABLE ONLY public.tb_kesintiler DROP CONSTRAINT pk_tb_kesintiler_kayitno;
ALTER TABLE ONLY public.tb_alacak_turleri DROP CONSTRAINT pk_tb_kesinti_turlari_kayitno;
ALTER TABLE ONLY public.tb_icralar DROP CONSTRAINT pk_tb_icralar_kayitno;
ALTER TABLE ONLY public.tb_icradairesi DROP CONSTRAINT pk_tb_icradairesi_kurumno;
ALTER TABLE ONLY public.tb_gmudurluk DROP CONSTRAINT pk_tb_gmudurlukj_kk0;
ALTER TABLE ONLY public.tb_ekler DROP CONSTRAINT pk_tb_ekler_kayit_numarasi;
ALTER TABLE ONLY public.tb_cevaplar DROP CONSTRAINT pk_tb_cevaplar_kayitno;
ALTER TABLE ONLY public.tb_borclular DROP CONSTRAINT idx_tb_borclular_kisi;
ALTER TABLE public.tb_icra_turleri ALTER COLUMN kayitno DROP DEFAULT;
DROP TABLE public.tb_personel;
DROP TABLE public.tb_muzekkereler;
DROP TABLE public.tb_kurumlar;
DROP TABLE public.tb_kesintiler;
DROP TABLE public.tb_icralar;
DROP TABLE public.tb_icradairesi;
DROP SEQUENCE public.tb_icra_turleri_kayitno_seq;
DROP TABLE public.tb_icra_turleri;
DROP TABLE public.tb_icra_alacak;
DROP TABLE public.tb_gmudurluk;
DROP TABLE public.tb_ekler;
DROP TABLE public.tb_cevaplar_ekler;
DROP TABLE public.tb_cevaplar;
DROP TABLE public.tb_borclular;
DROP TABLE public.tb_alacak_turleri;
DROP FUNCTION public.addicra(esasno_ character varying, tarih_ date, icra_dairesi_ integer, tutar_ money, icraturu_ integer, borclu_ bigint[], alacak_ integer[]);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: addicra(character varying, date, integer, money, integer, bigint[], integer[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.addicra(esasno_ character varying, tarih_ date, icra_dairesi_ integer, tutar_ money, icraturu_ integer, borclu_ bigint[], alacak_ integer[]) RETURNS void
    LANGUAGE plpgsql
    AS $$ 
declare icraKayitNo integer;
declare i bigint;
declare j bigint;
declare array_len int;
declare kisiNo int;
begin
								   
insert into tb_icralar (esasno, tarih, icradairesi, tutar, icraturu) values (esasno_, tarih_, icra_dairesi_, tutar_, icraturu_) returning kayitno into icraKayitNo;
 array_len:=array_upper(borclu_,1);
for i in  0..array_len
 loop
select  kisi_no into kisiNo from tb_personel where tc_no = borclu_[i];
insert into tb_borclular values (icraKayitNo, kisiNo);
 end loop;

													  
 array_len:=array_upper(alacak_,1);
for j in  0..array_len	
													  loop										  
insert into tb_icra_alacak values (icraKayitNo, alacak_[j]);
 end loop;										  
end

$$;


ALTER FUNCTION public.addicra(esasno_ character varying, tarih_ date, icra_dairesi_ integer, tutar_ money, icraturu_ integer, borclu_ bigint[], alacak_ integer[]) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_alacak_turleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_alacak_turleri (
    kayitno integer NOT NULL,
    turadi character varying(50) NOT NULL
);


ALTER TABLE public.tb_alacak_turleri OWNER TO postgres;

--
-- Name: tb_borclular; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_borclular (
    icra integer NOT NULL,
    kisi integer NOT NULL
);


ALTER TABLE public.tb_borclular OWNER TO postgres;

--
-- Name: tb_cevaplar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_cevaplar (
    kayitno integer NOT NULL,
    icra integer NOT NULL,
    evraktarihi date NOT NULL,
    evraksayisi integer NOT NULL,
    goruntu bytea,
    dosya_uzantisi character varying(5)
);


ALTER TABLE public.tb_cevaplar OWNER TO postgres;

--
-- Name: tb_cevaplar_ekler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_cevaplar_ekler (
    "kayitNo" integer NOT NULL,
    "YaziNo" integer NOT NULL,
    goruntu bytea NOT NULL,
    "dosyaUzantisi" text NOT NULL
);


ALTER TABLE public.tb_cevaplar_ekler OWNER TO postgres;

--
-- Name: tb_cevaplar_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_cevaplar ALTER COLUMN kayitno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_cevaplar_kayitno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_ekler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_ekler (
    kayit_numarasi integer NOT NULL,
    evrak_kayit_numarasi integer NOT NULL,
    goruntu bytea NOT NULL,
    dosya_uzanti character varying(5) NOT NULL
);


ALTER TABLE public.tb_ekler OWNER TO postgres;

--
-- Name: tb_ekler_kayit_numarasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_ekler ALTER COLUMN kayit_numarasi ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_ekler_kayit_numarasi_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_gmudurluk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_gmudurluk (
    kk0 smallint NOT NULL,
    kk1 smallint NOT NULL,
    kk2 smallint NOT NULL,
    kk3 smallint NOT NULL,
    kk4 smallint NOT NULL,
    adi text NOT NULL
);


ALTER TABLE public.tb_gmudurluk OWNER TO postgres;

--
-- Name: TABLE tb_gmudurluk; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_gmudurluk IS 'Genel Müdürlüklerin Listesi';


--
-- Name: COLUMN tb_gmudurluk.kk0; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_gmudurluk.kk0 IS 'ana kurum kodu';


--
-- Name: COLUMN tb_gmudurluk.kk1; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_gmudurluk.kk1 IS 'kurum kodu 1';


--
-- Name: COLUMN tb_gmudurluk.kk2; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_gmudurluk.kk2 IS 'kurum kodu 2';


--
-- Name: COLUMN tb_gmudurluk.kk3; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_gmudurluk.kk3 IS 'kurum kodu 3';


--
-- Name: COLUMN tb_gmudurluk.kk4; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_gmudurluk.kk4 IS 'kurum kodu 4';


--
-- Name: tb_gmudurlukj_kk0_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_gmudurluk ALTER COLUMN kk0 ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_gmudurlukj_kk0_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_icra_alacak; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_icra_alacak (
    "icraKayitNo" integer NOT NULL,
    "alacakTurNo" integer NOT NULL
);


ALTER TABLE public.tb_icra_alacak OWNER TO postgres;

--
-- Name: tb_icra_turleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_icra_turleri (
    turadi text NOT NULL,
    kayitno integer NOT NULL
);


ALTER TABLE public.tb_icra_turleri OWNER TO postgres;

--
-- Name: tb_icra_turleri_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_icra_turleri_kayitno_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_icra_turleri_kayitno_seq OWNER TO postgres;

--
-- Name: tb_icra_turleri_kayitno_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_icra_turleri_kayitno_seq OWNED BY public.tb_icra_turleri.kayitno;


--
-- Name: tb_icradairesi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_icradairesi (
    kurumno integer NOT NULL,
    "adı" text NOT NULL,
    banka text,
    iban text
);


ALTER TABLE public.tb_icradairesi OWNER TO postgres;

--
-- Name: tb_icradairesi_kurumno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_icradairesi ALTER COLUMN kurumno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_icradairesi_kurumno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_icralar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_icralar (
    kayitno integer NOT NULL,
    esasno character varying(25) NOT NULL,
    tarih date NOT NULL,
    icradairesi integer NOT NULL,
    tutar money,
    icraturu integer NOT NULL
);


ALTER TABLE public.tb_icralar OWNER TO postgres;

--
-- Name: tb_icralar_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_icralar ALTER COLUMN kayitno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_icralar_kayitno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_kesinti_turlari_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_alacak_turleri ALTER COLUMN kayitno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_kesinti_turlari_kayitno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_kesintiler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_kesintiler (
    kayitno integer NOT NULL,
    kisi integer NOT NULL,
    icra integer NOT NULL,
    tur integer NOT NULL,
    tarih date NOT NULL,
    tutar money
);


ALTER TABLE public.tb_kesintiler OWNER TO postgres;

--
-- Name: tb_kesintiler_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_kesintiler ALTER COLUMN kayitno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_kesintiler_kayitno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_kurumlar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_kurumlar (
    kk5 smallint NOT NULL,
    genelmudurluk smallint NOT NULL,
    adi text NOT NULL
);


ALTER TABLE public.tb_kurumlar OWNER TO postgres;

--
-- Name: TABLE tb_kurumlar; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_kurumlar IS 'okul-kurumların listesi';


--
-- Name: COLUMN tb_kurumlar.genelmudurluk; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_kurumlar.genelmudurluk IS 'genel müdürlük kodu';


--
-- Name: COLUMN tb_kurumlar.adi; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_kurumlar.adi IS 'kurum adı';


--
-- Name: tb_muzekkereler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_muzekkereler (
    kayitno integer NOT NULL,
    gelistarihi date NOT NULL,
    icra integer NOT NULL,
    goruntu bytea,
    dosya_uzantantisi character varying(5)
);


ALTER TABLE public.tb_muzekkereler OWNER TO postgres;

--
-- Name: tb_muzekkereler_kayitno_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tb_muzekkereler ALTER COLUMN kayitno ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.tb_muzekkereler_kayitno_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tb_personel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_personel (
    kisi_no integer NOT NULL,
    tc_no bigint NOT NULL,
    ckurum smallint NOT NULL,
    "adı" character varying(30) NOT NULL,
    "soyadı" character varying(40) NOT NULL
);


ALTER TABLE public.tb_personel OWNER TO postgres;

--
-- Name: TABLE tb_personel; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tb_personel IS 'personellerin listesi';


--
-- Name: COLUMN tb_personel.kisi_no; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_personel.kisi_no IS 'kphys kişi no';


--
-- Name: COLUMN tb_personel.tc_no; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_personel.tc_no IS 'kimlik numarası';


--
-- Name: COLUMN tb_personel.ckurum; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_personel.ckurum IS 'çalıştığı kurum';


--
-- Name: COLUMN tb_personel."adı"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_personel."adı" IS 'kişi adı';


--
-- Name: COLUMN tb_personel."soyadı"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.tb_personel."soyadı" IS 'kişinin soyadı';


--
-- Name: tb_icra_turleri kayitno; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icra_turleri ALTER COLUMN kayitno SET DEFAULT nextval('public.tb_icra_turleri_kayitno_seq'::regclass);


--
-- Data for Name: tb_alacak_turleri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_alacak_turleri (kayitno, turadi) FROM stdin;
\.
COPY public.tb_alacak_turleri (kayitno, turadi) FROM '$$PATH$$/2933.dat';

--
-- Data for Name: tb_borclular; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_borclular (icra, kisi) FROM stdin;
\.
COPY public.tb_borclular (icra, kisi) FROM '$$PATH$$/2931.dat';

--
-- Data for Name: tb_cevaplar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_cevaplar (kayitno, icra, evraktarihi, evraksayisi, goruntu, dosya_uzantisi) FROM stdin;
\.
COPY public.tb_cevaplar (kayitno, icra, evraktarihi, evraksayisi, goruntu, dosya_uzantisi) FROM '$$PATH$$/2939.dat';

--
-- Data for Name: tb_cevaplar_ekler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_cevaplar_ekler ("kayitNo", "YaziNo", goruntu, "dosyaUzantisi") FROM stdin;
\.
COPY public.tb_cevaplar_ekler ("kayitNo", "YaziNo", goruntu, "dosyaUzantisi") FROM '$$PATH$$/2944.dat';

--
-- Data for Name: tb_ekler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_ekler (kayit_numarasi, evrak_kayit_numarasi, goruntu, dosya_uzanti) FROM stdin;
\.
COPY public.tb_ekler (kayit_numarasi, evrak_kayit_numarasi, goruntu, dosya_uzanti) FROM '$$PATH$$/2941.dat';

--
-- Data for Name: tb_gmudurluk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_gmudurluk (kk0, kk1, kk2, kk3, kk4, adi) FROM stdin;
\.
COPY public.tb_gmudurluk (kk0, kk1, kk2, kk3, kk4, adi) FROM '$$PATH$$/2924.dat';

--
-- Data for Name: tb_icra_alacak; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_icra_alacak ("icraKayitNo", "alacakTurNo") FROM stdin;
\.
COPY public.tb_icra_alacak ("icraKayitNo", "alacakTurNo") FROM '$$PATH$$/2942.dat';

--
-- Data for Name: tb_icra_turleri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_icra_turleri (turadi, kayitno) FROM stdin;
\.
COPY public.tb_icra_turleri (turadi, kayitno) FROM '$$PATH$$/2943.dat';

--
-- Data for Name: tb_icradairesi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_icradairesi (kurumno, "adı", banka, iban) FROM stdin;
\.
COPY public.tb_icradairesi (kurumno, "adı", banka, iban) FROM '$$PATH$$/2928.dat';

--
-- Data for Name: tb_icralar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_icralar (kayitno, esasno, tarih, icradairesi, tutar, icraturu) FROM stdin;
\.
COPY public.tb_icralar (kayitno, esasno, tarih, icradairesi, tutar, icraturu) FROM '$$PATH$$/2930.dat';

--
-- Data for Name: tb_kesintiler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_kesintiler (kayitno, kisi, icra, tur, tarih, tutar) FROM stdin;
\.
COPY public.tb_kesintiler (kayitno, kisi, icra, tur, tarih, tutar) FROM '$$PATH$$/2935.dat';

--
-- Data for Name: tb_kurumlar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_kurumlar (kk5, genelmudurluk, adi) FROM stdin;
\.
COPY public.tb_kurumlar (kk5, genelmudurluk, adi) FROM '$$PATH$$/2925.dat';

--
-- Data for Name: tb_muzekkereler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_muzekkereler (kayitno, gelistarihi, icra, goruntu, dosya_uzantantisi) FROM stdin;
\.
COPY public.tb_muzekkereler (kayitno, gelistarihi, icra, goruntu, dosya_uzantantisi) FROM '$$PATH$$/2937.dat';

--
-- Data for Name: tb_personel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_personel (kisi_no, tc_no, ckurum, "adı", "soyadı") FROM stdin;
\.
COPY public.tb_personel (kisi_no, tc_no, ckurum, "adı", "soyadı") FROM '$$PATH$$/2926.dat';

--
-- Name: tb_cevaplar_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_cevaplar_kayitno_seq', 1, false);


--
-- Name: tb_ekler_kayit_numarasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_ekler_kayit_numarasi_seq', 1, false);


--
-- Name: tb_gmudurlukj_kk0_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_gmudurlukj_kk0_seq', 3, true);


--
-- Name: tb_icra_turleri_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_icra_turleri_kayitno_seq', 3, true);


--
-- Name: tb_icradairesi_kurumno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_icradairesi_kurumno_seq', 2, true);


--
-- Name: tb_icralar_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_icralar_kayitno_seq', 81, true);


--
-- Name: tb_kesinti_turlari_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_kesinti_turlari_kayitno_seq', 3, true);


--
-- Name: tb_kesintiler_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_kesintiler_kayitno_seq', 1, false);


--
-- Name: tb_muzekkereler_kayitno_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_muzekkereler_kayitno_seq', 1, false);


--
-- Name: tb_borclular idx_tb_borclular_kisi; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_borclular
    ADD CONSTRAINT idx_tb_borclular_kisi UNIQUE (kisi);


--
-- Name: tb_cevaplar pk_tb_cevaplar_kayitno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_cevaplar
    ADD CONSTRAINT pk_tb_cevaplar_kayitno PRIMARY KEY (kayitno);


--
-- Name: tb_ekler pk_tb_ekler_kayit_numarasi; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ekler
    ADD CONSTRAINT pk_tb_ekler_kayit_numarasi PRIMARY KEY (kayit_numarasi);


--
-- Name: tb_gmudurluk pk_tb_gmudurlukj_kk0; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_gmudurluk
    ADD CONSTRAINT pk_tb_gmudurlukj_kk0 PRIMARY KEY (kk0);


--
-- Name: tb_icradairesi pk_tb_icradairesi_kurumno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icradairesi
    ADD CONSTRAINT pk_tb_icradairesi_kurumno PRIMARY KEY (kurumno);


--
-- Name: tb_icralar pk_tb_icralar_kayitno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icralar
    ADD CONSTRAINT pk_tb_icralar_kayitno PRIMARY KEY (kayitno);


--
-- Name: tb_alacak_turleri pk_tb_kesinti_turlari_kayitno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_alacak_turleri
    ADD CONSTRAINT pk_tb_kesinti_turlari_kayitno PRIMARY KEY (kayitno);


--
-- Name: tb_kesintiler pk_tb_kesintiler_kayitno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kesintiler
    ADD CONSTRAINT pk_tb_kesintiler_kayitno PRIMARY KEY (kayitno);


--
-- Name: tb_kurumlar pk_tb_kurumlar_kk5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kurumlar
    ADD CONSTRAINT pk_tb_kurumlar_kk5 PRIMARY KEY (kk5);


--
-- Name: tb_muzekkereler pk_tb_muzekkereler_kayitno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_muzekkereler
    ADD CONSTRAINT pk_tb_muzekkereler_kayitno PRIMARY KEY (kayitno);


--
-- Name: tb_personel pk_tb_personel_kişi_no; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_personel
    ADD CONSTRAINT "pk_tb_personel_kişi_no" PRIMARY KEY (kisi_no);


--
-- Name: tb_icra_turleri pkey_icra_turleri; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icra_turleri
    ADD CONSTRAINT pkey_icra_turleri PRIMARY KEY (kayitno);


--
-- Name: tb_cevaplar_ekler tb_cevaplar_ekler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_cevaplar_ekler
    ADD CONSTRAINT tb_cevaplar_ekler_pkey PRIMARY KEY ("kayitNo");


--
-- Name: tb_personel unq_tcno; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_personel
    ADD CONSTRAINT unq_tcno UNIQUE (tc_no);


--
-- Name: fki_fk_icralar_turler; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_fk_icralar_turler ON public.tb_icralar USING btree (icraturu);


--
-- Name: idx_tb_borclular_icra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_borclular_icra ON public.tb_borclular USING btree (icra);


--
-- Name: idx_tb_cevaplar_icra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_cevaplar_icra ON public.tb_cevaplar USING btree (icra);


--
-- Name: idx_tb_ekler_evrak_kayit_numarasi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_ekler_evrak_kayit_numarasi ON public.tb_ekler USING btree (evrak_kayit_numarasi);


--
-- Name: idx_tb_icralar_icradairesi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_icralar_icradairesi ON public.tb_icralar USING btree (icradairesi);


--
-- Name: idx_tb_kesintiler_icra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_kesintiler_icra ON public.tb_kesintiler USING btree (icra);


--
-- Name: idx_tb_kesintiler_kisi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_kesintiler_kisi ON public.tb_kesintiler USING btree (kisi);


--
-- Name: idx_tb_kesintiler_tur; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_kesintiler_tur ON public.tb_kesintiler USING btree (tur);


--
-- Name: idx_tb_kurumlar_genelmudurluk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_kurumlar_genelmudurluk ON public.tb_kurumlar USING btree (genelmudurluk);


--
-- Name: idx_tb_muzekkereler_icra; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_muzekkereler_icra ON public.tb_muzekkereler USING btree (icra);


--
-- Name: idx_tb_personel_ckurum; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tb_personel_ckurum ON public.tb_personel USING btree (ckurum);


--
-- Name: tb_icra_alacak fk_alacak_icra-alacak; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icra_alacak
    ADD CONSTRAINT "fk_alacak_icra-alacak" FOREIGN KEY ("alacakTurNo") REFERENCES public.tb_alacak_turleri(kayitno);


--
-- Name: tb_icra_alacak fk_alacak_icra-icra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icra_alacak
    ADD CONSTRAINT "fk_alacak_icra-icra" FOREIGN KEY ("icraKayitNo") REFERENCES public.tb_icralar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_cevaplar_ekler fk_ekler_cevaplar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_cevaplar_ekler
    ADD CONSTRAINT fk_ekler_cevaplar FOREIGN KEY ("YaziNo") REFERENCES public.tb_cevaplar(kayitno);


--
-- Name: tb_icralar fk_icralar_turler; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icralar
    ADD CONSTRAINT fk_icralar_turler FOREIGN KEY (icraturu) REFERENCES public.tb_icra_turleri(kayitno);


--
-- Name: tb_borclular fk_tb_borclular_tb_icralar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_borclular
    ADD CONSTRAINT fk_tb_borclular_tb_icralar FOREIGN KEY (icra) REFERENCES public.tb_icralar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_borclular fk_tb_borclular_tb_personel; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_borclular
    ADD CONSTRAINT fk_tb_borclular_tb_personel FOREIGN KEY (kisi) REFERENCES public.tb_personel(kisi_no);


--
-- Name: tb_cevaplar fk_tb_cevaplar_tb_icralar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_cevaplar
    ADD CONSTRAINT fk_tb_cevaplar_tb_icralar FOREIGN KEY (icra) REFERENCES public.tb_icralar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_ekler fk_tb_ekler_tb_cevaplar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_ekler
    ADD CONSTRAINT fk_tb_ekler_tb_cevaplar FOREIGN KEY (evrak_kayit_numarasi) REFERENCES public.tb_cevaplar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_icralar fk_tb_icralar_tb_icradairesi; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_icralar
    ADD CONSTRAINT fk_tb_icralar_tb_icradairesi FOREIGN KEY (icradairesi) REFERENCES public.tb_icradairesi(kurumno) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tb_kesintiler fk_tb_kesintiler; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kesintiler
    ADD CONSTRAINT fk_tb_kesintiler FOREIGN KEY (tur) REFERENCES public.tb_alacak_turleri(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_kesintiler fk_tb_kesintiler_tb_icralar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kesintiler
    ADD CONSTRAINT fk_tb_kesintiler_tb_icralar FOREIGN KEY (icra) REFERENCES public.tb_icralar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_kesintiler fk_tb_kesintiler_tb_personel; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kesintiler
    ADD CONSTRAINT fk_tb_kesintiler_tb_personel FOREIGN KEY (kisi) REFERENCES public.tb_borclular(kisi) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_kurumlar fk_tb_kurumlar_tb_gmudurluk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kurumlar
    ADD CONSTRAINT fk_tb_kurumlar_tb_gmudurluk FOREIGN KEY (genelmudurluk) REFERENCES public.tb_gmudurluk(kk0) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: tb_muzekkereler fk_tb_muzekkereler_tb_icralar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_muzekkereler
    ADD CONSTRAINT fk_tb_muzekkereler_tb_icralar FOREIGN KEY (icra) REFERENCES public.tb_icralar(kayitno) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tb_personel fk_tb_personel_tb_kurumlar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_personel
    ADD CONSTRAINT fk_tb_personel_tb_kurumlar FOREIGN KEY (ckurum) REFERENCES public.tb_kurumlar(kk5) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

